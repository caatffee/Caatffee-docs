# ⭐ Sistema Premium

> 🌍 [English version → Premium System](../en/premium-system.md)

---

## ¿Qué es el Premium?

El sistema premium de Caatffee otorga beneficios adicionales a quienes apoyan el proyecto mediante donaciones voluntarias en Patreon.

> ⚠️ Las funciones **principales** del bot son **siempre gratuitas**. El premium solo añade extras.

---

## 💰 Planes Disponibles

| Plan | Precio | Badge |
|------|--------|-------|
| ☕ Básico | $3.99/mes | ⭐ |
| 🌸 Intermedio | $5.00/mes | 💠 |
| ⚡ Avanzado | $10.00/mes | 🔮 |
| 🔥 Ultra | $15.00/mes | 🔥 |

[Ver planes completos en Patreon →](https://www.patreon.com/15613390/join)

---

## 🎁 Beneficios por Plan

### ☕ Básico ($3.99)
- Rol exclusivo **Barista Donador Básico** + rol Premium en el servidor de soporte
- Estadísticas avanzadas básicas
- Prioridad ligera en soporte
- Canal exclusivo de sugerencias

### 🌸 Intermedio ($5.00)
- Todo lo del plan Básico +
- Rol **Barista Donador Intermedio**
- Más opciones en el dashboard
- Personalizar nombre del panel
- Plantillas exclusivas de servidor
- Logs avanzados

### ⚡ Avanzado ($10.00)
- Todo lo del plan Intermedio +
- Rol **Barista Donador Avanzado**
- Comandos exclusivos avanzados
- Personalización del panel
- Plantillas premium

### 🔥 Ultra ($15.00)
- Todo lo del plan Avanzado +
- Rol **Barista Donador Ultra**
- Badge ULTRA visible en el panel
- Tu servidor recomendado en la web oficial
- Acceso temprano a nuevas funciones
- Soporte prioritario real
- Integraciones exclusivas futuras
- Panel premium extendido

---

## ❓ Preguntas sobre Premium

**¿Las donaciones son reembolsables?**
No. Las donaciones son voluntarias y no reembolsables.

**¿Qué pasa si cancelo mi suscripción?**
Perderás los beneficios premium al final del período pagado.

**¿Puedo cambiar de plan?**
Sí, puedes subir o bajar de plan en Patreon en cualquier momento.

---

← [Panel Web](panel-web.md) | [FAQ →](faq.md)
