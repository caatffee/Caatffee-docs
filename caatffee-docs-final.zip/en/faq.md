# ❓ Frequently Asked Questions (../es/faq.md)

> 🌍 [Versión en español → FAQ](../es/faq.md)

---

**Is Caatffee free?**
Yes. Caatffee is completely free. Donations are voluntary and only grant extra benefits.

---

**How do I add the bot?**
Click [this link](https://discord.com/oauth2/authorize?client_id=1475842620063485993&permissions=8&scope=bot%20applications.commands) and select your server. You need to be an administrator.

---

**Does the bot collect my messages?**
No. We only store server, channel, and user IDs needed for functionality. We never store private message content.

---

**Why does it need administrator permission?**
So management commands work correctly. We never use those permissions beyond what you command.

---

**A command isn't responding, what do I do?**
1. Check that the bot has permissions in that channel
2. Make sure the bot is online
3. Report the error [here](https://caatffee.github.io/Caatffee/#report)

---

**How do I delete my data?**
Remove the bot from your server — data is deleted automatically. You can also request it in the [support server](https://discord.gg/ecjgjx7yPd).

---

**How often is the bot updated?**
Constantly. Check the [Changelog](../changelog.md) for the latest updates.

---

← [Premium System](premium-system.md) | [Changelog →](../changelog.md)
